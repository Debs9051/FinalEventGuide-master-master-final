package events.tcs.com.events.constant;

public interface ApplicationData {

    int SPLASH_TIME_OUT = 3000;
    String TAG = "EVENTS APPLICATION";
    String USER_KEY = "user";
    Double hotelLat = 0.0;
    Double hotelLan = 0.0;
    Double gpLat = 22.58148;
    Double gpLan = 88.48741;
    Double noLat=0.0;
Double noLan=0.0;
}
